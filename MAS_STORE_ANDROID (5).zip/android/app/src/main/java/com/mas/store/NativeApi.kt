package com.mas.store

import android.app.Notification
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.webkit.JavascriptInterface
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
import androidx.core.content.pm.PackageInfoCompat
import org.json.JSONObject

class NativeApi(private val a: MainActivity) {

    @JavascriptInterface fun isInstalled(pkg: String): Boolean =
        try { a.packageManager.getPackageInfo(pkg, 0); true } catch (e: Exception) { false }

    @JavascriptInterface fun open(pkg: String): Boolean {
        val i = a.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        a.startActivity(i); return true
    }

    @JavascriptInterface fun openExternal(url: String) {
        a.runOnUiThread {
            try { CustomTabsIntent.Builder().build().launchUrl(a, Uri.parse(url)) }
            catch (e: Exception) { a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        }
    }

    @JavascriptInterface fun notify(title: String, body: String) {
        Notif.init(a)
        Notif.show(a, (System.currentTimeMillis() % 100000).toInt(), Notif.builder(a, Notif.CH_DONE).setContentTitle(title).setContentText(body)
            .setAutoCancel(true).setContentIntent(Notif.openApp(a)).setDefaults(Notification.DEFAULT_ALL).build())
    }

    @JavascriptInterface fun openSite(url: String, title: String) {
        a.runOnUiThread { a.startActivity(Intent(a, SiteActivity::class.java).putExtra("url", url).putExtra("title", title)) }
    }

    @JavascriptInterface fun getActive(): String = DownloadService.json()

    @JavascriptInterface fun setNotify(on: Boolean) {
        a.getSharedPreferences("mas", Context.MODE_PRIVATE).edit().putBoolean("notify", on).apply()
    }

    @JavascriptInterface fun getVersion(): String = try {
        val pi = a.packageManager.getPackageInfo(a.packageName, 0)
        (pi.versionName ?: "") + " (" + PackageInfoCompat.getLongVersionCode(pi) + ")"
    } catch (e: Exception) { "" }

    @JavascriptInterface fun cancel(id: String) {
        val item = DownloadService.active[id] ?: return
        if (item.state == "install") DownloadService.cancelInstall(a, item)
        else a.startService(Intent(a, DownloadService::class.java).setAction("CANCEL").putExtra("id", id))
    }

    @JavascriptInterface fun install(url: String, id: String, title: String, sha: String) {
        if (!a.packageManager.canRequestPackageInstalls()) {
            a.runOnUiThread { a.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + a.packageName))) }
            Bridge.emit(JSONObject().put("type", "permission").put("id", id)); return
        }
        ContextCompat.startForegroundService(a, Intent(a, DownloadService::class.java).setAction("START")
            .putExtra("url", url).putExtra("id", id).putExtra("title", title).putExtra("sha", sha))
    }
}
