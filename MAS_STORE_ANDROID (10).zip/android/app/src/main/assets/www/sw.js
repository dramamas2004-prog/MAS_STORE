self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('activate',e=>e.waitUntil(clients.claim()));
self.addEventListener('push',e=>{let d={};try{d=e.data.json()}catch(_){d={title:'MAS STORE',body:e.data?e.data.text():''}}
 if(d.badge!=null&&self.navigator.setAppBadge){self.navigator.setAppBadge(d.badge).catch(()=>{})}
 e.waitUntil(self.registration.showNotification(d.title||'MAS STORE',{body:d.body||'',icon:'icon-192.png',badge:'badge-72.png',vibrate:[200,100,200],tag:d.tag,data:{url:d.url||'./'}}))});
self.addEventListener('notificationclick',e=>{e.notification.close();const u=e.notification.data&&e.notification.data.url||'./';
 e.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(l=>{for(const c of l){if('focus' in c){c.postMessage({type:'open-notifications'});return c.focus()}}return clients.openWindow(u)}))});
