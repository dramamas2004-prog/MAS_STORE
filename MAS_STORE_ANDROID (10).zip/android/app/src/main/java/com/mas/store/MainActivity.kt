package com.mas.store

import android.Manifest
import android.annotation.SuppressLint
import android.content.*
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.*
import androidx.appcompat.app.AppCompatActivity
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import com.google.firebase.messaging.FirebaseMessaging
import org.json.JSONObject

// غيّر الرابط لو دومين متجرك اتغيّر (وغيّره كمان في AndroidManifest.xml)
// واجهة المتجر مدمجة داخل التطبيق نفسه (assets/www) وتُعرض محليًا، مش رابط موقع
const val STORE_URL = "https://appassets.androidplatform.net/assets/www/index.html"

object Bridge {
    var web: WebView? = null
    fun emit(o: JSONObject) {
        web?.post { web?.evaluateJavascript("window.onNativeEvent&&window.onNativeEvent(" + JSONObject.quote(o.toString()) + ")", null) }
    }
}

class MainActivity : AppCompatActivity() {
    companion object { @Volatile var visible = false }
    override fun onStart() { super.onStart(); visible = true }
    override fun onStop() { super.onStop(); visible = false }
    private lateinit var web: WebView
    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { Bridge.emit(JSONObject().put("type", "pkgchanged")) }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        Bridge.web = web
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.userAgentString = web.settings.userAgentString + " MASStoreApp"
        CookieManager.getInstance().setAcceptCookie(true)
        web.addJavascriptInterface(NativeApi(this), "MASAndroid")
        web.webChromeClient = WebChromeClient()
        val assetLoader = WebViewAssetLoader.Builder().addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                assetLoader.shouldInterceptRequest(request.url)
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url
                if (u.host == Uri.parse(STORE_URL).host) return false
                try { CustomTabsIntent.Builder().build().launchUrl(this@MainActivity, u) }
                catch (e: Exception) { startActivity(Intent(Intent.ACTION_VIEW, u)) }
                return true
            }
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED); addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, pkgReceiver, f, ContextCompat.RECEIVER_EXPORTED)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        fetchToken()
        web.loadUrl(urlFrom(intent))
    }

    private fun fetchToken() {
        try {
            FirebaseMessaging.getInstance().token.addOnSuccessListener { t ->
                getSharedPreferences("mas", MODE_PRIVATE).edit().putString("fcm", t).apply()
                Bridge.emit(JSONObject().put("type", "fcmtoken"))
            }
        } catch (e: Exception) {}
    }

    private fun pidFrom(i: Intent?): String? {
        val p = i?.getStringExtra("product_id") ?: return null
        return if (Regex("^[0-9a-fA-F-]{8,40}$").matches(p)) p else null
    }

    private fun urlFrom(i: Intent?): String {
        val u = i?.data ?: return (pidFrom(i)?.let { STORE_URL + "?open=" + it } ?: STORE_URL)
        // رابط مشاركة منتج: https://.../p/<id> يفتح المنتج مباشرة
        val seg = u.pathSegments
        if (seg.size == 2 && seg[0] == "p" && Regex("^[0-9a-fA-F-]{8,40}$").matches(seg[1])) return STORE_URL + "?open=" + seg[1]
        val q = u.encodedQuery; val fr = u.encodedFragment
        return STORE_URL + "?r=" + System.currentTimeMillis() + (if (q != null) "&$q" else "") + (if (fr != null) "#$fr" else "")
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.data != null) web.loadUrl(urlFrom(intent))
        else pidFrom(intent)?.let { web.evaluateJavascript("window.masOpenProduct&&window.masOpenProduct('" + it + "')", null) }
    }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // الرجوع خطوة خطوة داخل المتجر (نافذة ثم قسم)، ولو مفيش حاجة يخرج من التطبيق
        web.evaluateJavascript("(function(){return !!(window.masBack&&window.masBack())})()") { r ->
            if (r != "true") { if (web.canGoBack()) web.goBack() else finish() }
        }
    }
    override fun onDestroy() { try { unregisterReceiver(pkgReceiver) } catch (e: Exception) {}; super.onDestroy() }
}
