package com.mas.store

internal object SupabaseConfig {
    const val URL = "https://nfoelysrjoeptiathwem.supabase.co"
    const val ANON_KEY = "sb_publishable_2RCiXlVINs3jNvS-Ok_joQ_Rh_vTM2M"
}
