package com.mas.store

import android.content.Context
import android.net.Uri
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom

internal data class StoreSnapshot(
    val products: List<JSONObject> = emptyList(),
    val packages: List<JSONObject> = emptyList(),
    val sections: List<JSONObject> = emptyList(),
    val announcements: List<JSONObject> = emptyList(),
    val settings: Map<String, String> = emptyMap()
)

/** Supabase REST/Auth client. It uses the same project and anon key as the web store and admin. */
internal class StoreRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("mas-native", Context.MODE_PRIVATE)
    private var accessToken: String? = prefs.getString("access_token", null)
    private var refreshToken: String? = prefs.getString("refresh_token", null)
    private val http = OkHttpClient.Builder().connectTimeout(18, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(26, java.util.concurrent.TimeUnit.SECONDS).build()
    var userId: String? = prefs.getString("user_id", null)
        private set
    var email: String? = prefs.getString("email", null)
        private set
    val isSignedIn: Boolean get() = !accessToken.isNullOrBlank()

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun api(path: String) = SupabaseConfig.URL.trimEnd('/') + path

    private suspend fun request(method: String, path: String, body: JSONObject? = null, auth: Boolean = false,
                                prefer: String? = null): String = withContext(Dispatchers.IO) {
        val media = "application/json; charset=utf-8".toMediaType()
        val requestBody = body?.toString()?.toRequestBody(media)
        val builder = Request.Builder().url(api(path)).header("apikey", SupabaseConfig.ANON_KEY)
            .header("Authorization", "Bearer " + if (auth) accessToken.orEmpty() else SupabaseConfig.ANON_KEY)
            .header("Accept", "application/json")
        if (prefer != null) builder.header("Prefer", prefer)
        if (method == "GET" || method == "HEAD") builder.method(method, null)
        else builder.method(method, requestBody ?: "".toRequestBody(media))
        http.newCall(builder.build()).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IOException(errorMessage(text, response.code))
            text
        }
    }

    private fun errorMessage(text: String, code: Int): String = try {
        val j = JSONObject(text)
        j.optString("msg").ifBlank { j.optString("message").ifBlank { j.optString("error_description").ifBlank { j.optString("error").ifBlank { "تعذر الاتصال ($code)" } } } }
    } catch (_: Exception) { "تعذر الاتصال بالخادم ($code)" }

    private fun query(vararg p: Pair<String, String>) = p.joinToString("&") { enc(it.first) + "=" + enc(it.second) }
    private suspend fun table(name: String, vararg p: Pair<String, String>, auth: Boolean = false): JSONArray {
        val s = request("GET", "/rest/v1/$name?" + query(*p), auth = auth)
        return JSONArray(s)
    }
    private suspend fun rpc(name: String, args: JSONObject = JSONObject(), auth: Boolean = true): JSONObject {
        val s = request("POST", "/rest/v1/rpc/$name", args, auth = auth)
        return when { s.startsWith("{") -> JSONObject(s); s.startsWith("[") -> JSONObject().put("items", JSONArray(s)); else -> JSONObject().put("result", s) }
    }

    suspend fun loadStore(): StoreSnapshot {
        val products = table("products", "select" to "*", "is_published" to "eq.true", "order" to "created_at.desc")
        val packages = table("packages", "select" to "*", "is_active" to "eq.true", "order" to "sort_order.asc")
        val sections = safeTable("home_sections", "is_active" to "eq.true", "order" to "sort_order.asc")
        val announcements = safeTable("announcements", "is_active" to "eq.true", "order" to "created_at.desc")
        val settingsRows = safeTable("store_settings", "select" to "key,value")
        val settings = buildMap { for (i in 0 until settingsRows.length()) { val o=settingsRows.optJSONObject(i) ?: continue; put(o.optString("key"), o.optString("value")) } }
        return StoreSnapshot(products.objects(), packages.objects(), sections.objects(), announcements.objects(), settings)
    }

    private suspend fun safeTable(name: String, vararg p: Pair<String, String>): JSONArray = try {
        val params = if (p.any { it.first == "select" }) p else arrayOf("select" to "*") + p
        table(name, *params, auth = isSignedIn)
    } catch (_: Exception) { JSONArray() }

    suspend fun signIn(address: String, password: String) {
        val j = JSONObject().put("email", address.trim()).put("password", password)
        saveSession(JSONObject(request("POST", "/auth/v1/token?grant_type=password", j)))
    }

    suspend fun signUp(address: String, password: String, fullName: String) {
        val j = JSONObject().put("email", address.trim()).put("password", password)
            .put("data", JSONObject().put("full_name", fullName.trim()))
        val r = JSONObject(request("POST", "/auth/v1/signup", j))
        if (r.has("access_token")) saveSession(r)
        else throw IOException("تم إنشاء الحساب. راجع بريدك لتأكيده ثم سجّل الدخول.")
    }

    private fun saveSession(j: JSONObject) {
        val token = j.optString("access_token").ifBlank { throw IOException("لم يصل رمز تسجيل الدخول") }
        val user = j.optJSONObject("user") ?: JSONObject()
        accessToken = token
        refreshToken = j.optString("refresh_token").takeIf { it.isNotBlank() }
        userId = user.optString("id").takeIf { it.isNotBlank() }
        email = user.optString("email").takeIf { it.isNotBlank() }
        prefs.edit().putString("access_token", accessToken).putString("refresh_token", refreshToken)
            .putString("user_id", userId).putString("email", email).apply()
    }

    suspend fun refreshSession() {
        val token = refreshToken ?: return
        try { saveSession(JSONObject(request("POST", "/auth/v1/token?grant_type=refresh_token", JSONObject().put("refresh_token", token)))) }
        catch (_: Exception) { signOutLocal() }
    }

    suspend fun signOut() { try { request("POST", "/auth/v1/logout", JSONObject(), auth = true) } catch (_: Exception) {}; signOutLocal() }
    private fun signOutLocal() { accessToken = null; refreshToken = null; userId = null; email = null; prefs.edit().remove("access_token").remove("refresh_token").remove("user_id").remove("email").remove("oauth_verifier").apply() }

    suspend fun exchangeOAuthCode(code: String, verifier: String) {
        val j = JSONObject().put("auth_code", code).put("code_verifier", verifier)
        saveSession(JSONObject(request("POST", "/auth/v1/token?grant_type=pkce", j)))
        prefs.edit().remove("oauth_verifier").apply()
    }

    fun createOAuthUrl(): String {
        val bytes = ByteArray(48).also { SecureRandom().nextBytes(it) }
        val verifier = Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
        val challenge = Base64.encodeToString(MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray()), Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
        prefs.edit().putString("oauth_verifier", verifier).apply()
        return Uri.parse(api("/auth/v1/authorize")).buildUpon().appendQueryParameter("provider", "google")
            .appendQueryParameter("redirect_to", "masstore://auth").appendQueryParameter("code_challenge", challenge)
            .appendQueryParameter("code_challenge_method", "s256").build().toString()
    }

    suspend fun setBirthDate(date: String) { rpc("set_my_birth_date", JSONObject().put("p_date", date)) }
    suspend fun quote(productId: String) = rpc("get_product_quote", JSONObject().put("p_product_id", productId), auth = isSignedIn)
    suspend fun preregister(productId: String) = rpc("toggle_prereg", JSONObject().put("p_product_id", productId))
    suspend fun createPayment(productId: String?, packageId: String?, reference: String, phone: String, code: String) =
        rpc("create_payment_request", JSONObject().put("p_product_id", productId?.takeIf { it.isNotBlank() } ?: JSONObject.NULL)
            .put("p_package_id", packageId?.takeIf { it.isNotBlank() } ?: JSONObject.NULL).put("p_ref", reference.trim())
            .put("p_phone", if (phone.isBlank()) JSONObject.NULL else phone.trim()).put("p_code", if (code.isBlank()) JSONObject.NULL else code.trim()))
    suspend fun applyPromo(code: String, productId: String?, packageId: String?) = rpc("apply_promo", JSONObject()
        .put("p_code", code.trim()).put("p_product_id", productId ?: JSONObject.NULL).put("p_package_id", packageId ?: JSONObject.NULL))
    suspend fun getDownload(productId: String) = rpc("get_product_download_url", JSONObject().put("p_product_id", productId))

    suspend fun signedDownloadUrl(path: String): String {
        val encoded = path.split('/').joinToString("/") { enc(it).replace("+", "%20") }
        val r = JSONObject(request("POST", "/storage/v1/object/sign/store-downloads/$encoded", JSONObject().put("expiresIn", 900), auth = true))
        val signed = r.optString("signedURL").ifBlank { r.optString("signedUrl") }
        if (signed.isBlank()) throw IOException("تعذر تجهيز رابط التحميل")
        return if (signed.startsWith("http")) signed else api(if (signed.startsWith("/object/")) "/storage/v1$signed" else signed)
    }

    suspend fun confirmDownload(id: String) { rpc("confirm_download", JSONObject().put("p_product_id", id)) }
    suspend fun releaseDownload(id: String) { rpc("release_download", JSONObject().put("p_product_id", id)) }
    suspend fun accountSummary() = rpc("get_account_summary")
    suspend fun reviews(id: String): JSONArray { val r=rpc("get_product_reviews", JSONObject().put("p_product_id", id).put("p_limit", 30)); return r.optJSONArray("items") ?: r.optJSONArray("reviews") ?: JSONArray() }
    suspend fun addReview(id: String, rating: Int, comment: String) {
        val args = JSONObject().put("product_id", id).put("rating", rating).put("comment", comment.trim())
        request("POST", "/rest/v1/reviews", args, auth = true, prefer = "return=representation")
    }
    suspend fun notifications(): JSONArray = table("notifications", "select" to "*", "order" to "created_at.desc", "limit" to "60", auth = true)
    suspend fun markNotificationRead(id: String) { request("PATCH", "/rest/v1/notifications?id=eq.${enc(id)}", JSONObject().put("is_read", true), auth = true, prefer = "return=minimal") }
    suspend fun orders(): JSONArray = table("payment_requests", "select" to "*,products:product_id(title),packages:package_id(name)", "order" to "created_at.desc", "limit" to "60", auth = true)
    suspend fun tickets(): JSONArray = table("support_tickets", "select" to "*", "order" to "updated_at.desc", auth = true)
    suspend fun ticketMessages(id: String): JSONArray = table("support_messages", "select" to "*", "ticket_id" to "eq.$id", "order" to "created_at.asc", auth = true)
    suspend fun createTicket(category: String, subject: String, body: String, productId: String?) = rpc("create_ticket", JSONObject()
        .put("p_category", category).put("p_subject", subject).put("p_body", body).put("p_product", productId ?: JSONObject.NULL))
    suspend fun replyTicket(id: String, body: String) { rpc("reply_ticket", JSONObject().put("p_ticket", id).put("p_body", body)) }
    suspend fun closeTicket(id: String) { rpc("close_ticket", JSONObject().put("p_ticket", id)) }
    suspend fun updates(productId: String): JSONArray = table("product_updates", "select" to "*", "product_id" to "eq.$productId", "order" to "created_at.desc")
    suspend fun latestRelease(): JSONObject? = try { table("app_releases", "select" to "*", "is_active" to "eq.true", "order" to "created_at.desc", "limit" to "1").optJSONObject(0) } catch (_: Exception) { null }
    suspend fun trackDevice(deviceId: String, version: String) { rpc("track_device", JSONObject().put("p_device", deviceId).put("p_platform", "android").put("p_version", version), auth = isSignedIn) }
    suspend fun registerPush(token: String) { if (token.isNotBlank() && isSignedIn) rpc("register_push_token", JSONObject().put("p_token", token).put("p_platform", "android")) }
    suspend fun unregisterPush(token: String) { if (token.isNotBlank() && isSignedIn) rpc("unregister_push_token", JSONObject().put("p_token", token)) }

    private fun JSONArray.objects() = (0 until length()).mapNotNull { optJSONObject(it) }
}
