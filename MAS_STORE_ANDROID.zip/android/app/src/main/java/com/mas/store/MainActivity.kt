package com.mas.store

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.launch
import org.json.JSONObject

/** Main store experience is native Android UI. WebView is retained only by SiteActivity for website products. */
object Bridge {
    @Volatile var listener: ((JSONObject) -> Unit)? = null
    fun emit(o: JSONObject) { listener?.invoke(o) }
}

class MainActivity : AppCompatActivity() {
    companion object { @Volatile var visible = false }
    internal val repository by lazy { StoreRepository(this) }
    internal val nativeEvents = androidx.compose.runtime.mutableStateListOf<JSONObject>()
    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { Bridge.emit(JSONObject().put("type", "pkgchanged")) }
    }

    override fun onStart() { super.onStart(); visible = true }
    override fun onStop() { super.onStop(); visible = false }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyNativeTheme(getSharedPreferences("mas-native",0).getBoolean("dark",false))
        Bridge.listener = { event -> runOnUiThread { nativeEvents.add(event); while (nativeEvents.size > 12) nativeEvents.removeAt(0) } }
        ContextCompat.registerReceiver(this, pkgReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED); addDataScheme("package")
        }, ContextCompat.RECEIVER_EXPORTED)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent { MASStoreApp(this, repository, nativeEvents) }
        fetchToken()
        handleOAuth(intent)
        lifecycleScope.launch {
            try {
                val id = NativeApi(this@MainActivity).getDeviceId()
                repository.trackDevice(id, packageManager.getPackageInfo(packageName, 0).versionName ?: "2.0")
            } catch (_: Exception) { }
        }
    }

    internal fun applyNativeTheme(dark:Boolean) {
        val color=if(dark) android.graphics.Color.rgb(8,8,8) else android.graphics.Color.rgb(244,244,244)
        window.statusBarColor=color; window.navigationBarColor=color
        WindowInsetsControllerCompat(window,window.decorView).apply { isAppearanceLightStatusBars=!dark; isAppearanceLightNavigationBars=!dark }
    }

    private fun fetchToken() {
        try { FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
            getSharedPreferences("mas", MODE_PRIVATE).edit().putString("fcm", token).apply()
            lifecycleScope.launch { try { if(getSharedPreferences("mas-native",MODE_PRIVATE).getBoolean("push_enabled",true)) repository.registerPush(token) } catch (_: Exception) { } }
        } } catch (_: Exception) { }
    }

    private fun handleOAuth(i: Intent?) {
        val uri = i?.data ?: return
        if (uri.scheme == "masstore" && uri.host == "auth") {
            val code = uri.getQueryParameter("code")
            if (code != null) lifecycleScope.launch {
                try {
                    val verifier = getSharedPreferences("mas-native", MODE_PRIVATE).getString("oauth_verifier", null)
                        ?: throw IllegalStateException("تعذر إكمال تسجيل الدخول")
                    repository.exchangeOAuthCode(code, verifier)
                    repository.loadStore()
                    Bridge.emit(JSONObject().put("type", "auth"))
                    fetchToken()
                } catch (e: Exception) { Bridge.emit(JSONObject().put("type", "error").put("message", e.message ?: "تعذر تسجيل الدخول")) }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.data?.scheme == "masstore") { handleOAuth(intent); return }
        val u = intent.data
        val id = intent.getStringExtra("product_id") ?: u?.pathSegments?.lastOrNull()?.takeIf { u.host == "mas-store-six.vercel.app" }
        if (id != null && Regex("^[0-9a-fA-F-]{8,40}$").matches(id)) Bridge.emit(JSONObject().put("type", "open_product").put("id", id))
    }

    override fun onDestroy() {
        Bridge.listener = null
        try { unregisterReceiver(pkgReceiver) } catch (_: Exception) { }
        super.onDestroy()
    }
}
