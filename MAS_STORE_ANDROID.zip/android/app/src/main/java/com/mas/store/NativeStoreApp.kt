package com.mas.store

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.*
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

private val Ink = Color(0xFF171717)
private val Muted = Color(0xFF777777)
private val LightGlass = Color.White.copy(alpha = .67f)
private val DarkGlass = Color.White.copy(alpha = .09f)
private val Line = Color.White.copy(alpha = .68f)
private val Shape = RoundedCornerShape(24.dp)
private enum class StoreTab(val title: String, val icon: String) { Store("المتجر", "⌂"), Plans("الباقات", "◇"), Notices("الإشعارات", "◉"), Account("حسابي", "○"), Settings("الإعدادات", "⚙") }
private data class PurchaseTarget(val product: JSONObject? = null, val pack: JSONObject? = null, val amount: Double = 0.0)

@Composable
internal fun MASStoreApp(activity: MainActivity, repo: StoreRepository, nativeEvents: List<JSONObject>) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var dark by remember { mutableStateOf(activity.getSharedPreferences("mas-native", 0).getBoolean("dark", false)) }
    var signedIn by remember { mutableStateOf(repo.isSignedIn) }
    var signedEmail by remember { mutableStateOf(repo.email.orEmpty()) }
    var pushEnabled by remember { mutableStateOf(activity.getSharedPreferences("mas-native",0).getBoolean("push_enabled",true)) }
    var tab by remember { mutableStateOf(StoreTab.Store) }
    var snapshot by remember { mutableStateOf(StoreSnapshot()) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("all") }
    var sort by remember { mutableStateOf("new") }
    var selected by remember { mutableStateOf<JSONObject?>(null) }
    var showAuth by remember { mutableStateOf(false) }
    var purchase by remember { mutableStateOf<PurchaseTarget?>(null) }
    var account by remember { mutableStateOf<JSONObject?>(null) }
    var orders by remember { mutableStateOf(JSONArray()) }
    var notifications by remember { mutableStateOf(JSONArray()) }
    var tickets by remember { mutableStateOf(JSONArray()) }
    var selectedTicket by remember { mutableStateOf<JSONObject?>(null) }
    var toastText by remember { mutableStateOf("") }
    var release by remember { mutableStateOf<JSONObject?>(null) }
    val scheme = if (dark) darkColorScheme(primary = Color.White, onPrimary = Ink, background = Color(0xFF080808), surface = Color(0xFF141414), onSurface = Color(0xFFF4F4F4), surfaceVariant = Color(0xFF242424))
        else lightColorScheme(primary = Color(0xFF333333), onPrimary = Color.White, background = Color(0xFFF4F4F4), surface = Color.White, onSurface = Ink, surfaceVariant = Color(0xFFEAEAEA))

    fun toast(s: String) { toastText = s; Toast.makeText(context, s, Toast.LENGTH_SHORT).show() }
    suspend fun reload() { busy = true; error = ""; try { snapshot = repo.loadStore() } catch (e: Exception) { error = e.message ?: "تعذر تحميل المتجر" }; busy = false }
    fun launch(block: suspend () -> Unit) { scope.launch { try { block() } catch (e: Exception) { toast(e.message ?: "حدث خطأ") } } }
    fun openPurchase(target: PurchaseTarget) { purchase = target }
    fun startNativeDownload(p: JSONObject, detail: JSONObject) {
        val id = p.optString("id")
        val path = detail.optString("file_path")
        if (detail.has("url") && detail.optString("url").startsWith("http")) {
            NativeApi(activity).openSite(detail.optString("url"), p.optString("title")); return
        }
        launch {
            val url = if (detail.optString("signedURL").startsWith("http")) detail.optString("signedURL") else repo.signedDownloadUrl(path)
            NativeApi(activity).install(url, id, p.optString("title"), p.optString("file_sha256"))
            toast("بدأ تنزيل ${p.optString("title")}")
        }
    }
    fun productAction(p: JSONObject) {
        if (!signedIn) { showAuth = true; return }
        val packageName=p.optString("package_name")
        if(p.optString("category")=="app"&&packageName.isNotBlank()&&NativeApi(activity).isInstalled(packageName)) {
            if(!NativeApi(activity).open(packageName)) toast("تعذر فتح التطبيق")
            return
        }
        launch {
            val q = repo.quote(p.optString("id"))
            when (q.optString("age_block")) {
                "need_birth" -> toast("أضف تاريخ ميلادك من الحساب أولًا")
                "too_young" -> toast("هذا المحتوى غير مناسب لعمرك")
                else -> if (q.optBoolean("coming_soon")) {
                    val r = repo.preregister(p.optString("id")); toast(r.optString("message", "تم تحديث التسجيل المسبق")); reload()
                } else if (q.optDouble("pay", 0.0) > 0) openPurchase(PurchaseTarget(product = p, amount = q.optDouble("pay")))
                else {
                    val d = repo.getDownload(p.optString("id")); startNativeDownload(p, d)
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        if (repo.isSignedIn) try { repo.refreshSession(); signedIn=repo.isSignedIn; signedEmail=repo.email.orEmpty() } catch (_: Exception) { }
        reload()
        while (true) { delay(45000); try { snapshot = repo.loadStore() } catch (_: Exception) { } }
    }
    LaunchedEffect(tab, signedIn) {
        if (!signedIn) return@LaunchedEffect
        try {
            when (tab) {
                StoreTab.Account -> { account = repo.accountSummary(); orders = repo.orders() }
                StoreTab.Notices -> notifications = repo.notifications()
                else -> Unit
            }
        } catch (e: Exception) { error = e.message ?: "تعذر تحميل البيانات" }
    }
    LaunchedEffect(nativeEvents.size) {
        if (nativeEvents.isEmpty()) return@LaunchedEffect
        val e = nativeEvents.last(); when (e.optString("type")) {
            "done" -> { try { repo.confirmDownload(e.optString("id")) } catch (_: Exception) { }; toast("اكتمل التثبيت") }
            "error" -> toast(e.optString("msg").ifBlank { e.optString("message", "تعذر التثبيت") })
            "cancelled" -> toast("تم إلغاء التنزيل")
            "auth", "pkgchanged" -> { signedIn=repo.isSignedIn; signedEmail=repo.email.orEmpty(); reload(); if (tab == StoreTab.Account && signedIn) { account = try { repo.accountSummary() } catch (_: Exception) { null } } }
            "notification" -> { toast(e.optString("title") + ": " + e.optString("body")); if(signedIn) launch { try { notifications=repo.notifications() } catch (_:Exception) { } } }
            "open_product" -> { val found = snapshot.products.firstOrNull { it.optString("id") == e.optString("id") }; if (found != null) selected = found }
        }
    }
    BackHandler(selected != null || showAuth || purchase != null || selectedTicket != null) {
        when { selectedTicket != null -> selectedTicket = null; purchase != null -> purchase = null; showAuth -> showAuth = false; else -> selected = null }
    }

    MaterialTheme(colorScheme = scheme) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(if (dark) listOf(Color(0xFF080808), Color(0xFF191919), Color(0xFF090909)) else listOf(Color(0xFFFFFFFF), Color(0xFFEDEDED), Color(0xFFF7F7F7))))) {
            Column(Modifier.fillMaxSize()) {
                Header(dark, onTheme = { dark = !dark; activity.getSharedPreferences("mas-native", 0).edit().putBoolean("dark", dark).apply();activity.applyNativeTheme(dark) }, onAuth = { showAuth = true })
                if (error.isNotBlank()) GlassCard(dark, Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) { Text(error, color = MaterialTheme.colorScheme.onSurface); TextButton(onClick = { launch { reload() } }) { Text("إعادة المحاولة") } }
                when (tab) {
                    StoreTab.Store -> StoreScreen(snapshot, busy, search, { search = it }, category, { category = it }, sort, { sort = it }, dark, onProduct = { selected = it }, onAction = { productAction(it) }, onAnnouncement = { a -> when(a.optString("action")){"product"->snapshot.products.firstOrNull{it.optString("id")==a.optString("product_id")}?.let{selected=it};"plans"->tab=StoreTab.Plans;"support"->if(signedIn)launch{tickets=repo.tickets();selectedTicket=JSONObject().put("new",true)}else showAuth=true;"appupdate"->tab=StoreTab.Settings;else->Unit} })
                    StoreTab.Plans -> PlansScreen(snapshot.packages, dark, onBuy = { p -> if (!signedIn) showAuth = true else { val price = packagePrice(p); openPurchase(PurchaseTarget(pack = p, amount = price)) } })
                    StoreTab.Notices -> NoticeScreen(notifications, signedIn, dark, onLogin = { showAuth = true }, onOpen = { n -> launch { repo.markNotificationRead(n.optString("id")); notifications = repo.notifications() }; val pid=n.optString("product_id"); if(pid.isNotBlank()) snapshot.products.firstOrNull{it.optString("id")==pid}?.let{selected=it} })
                    StoreTab.Account -> AccountScreen(signedIn, signedEmail, account, orders, dark, onLogin = { showAuth = true }, onLogout = { launch { try{repo.unregisterPush(activity.getSharedPreferences("mas",0).getString("fcm","").orEmpty())}catch(_:Exception){};repo.signOut(); signedIn=false; signedEmail=""; account=null; orders=JSONArray(); toast("تم تسجيل الخروج") } }, onBirth = { date -> launch { repo.setBirthDate(date); toast("تم حفظ تاريخ الميلاد") } }, onSupport = { launch { tickets=repo.tickets(); selectedTicket=JSONObject().put("new",true) } })
                    StoreTab.Settings -> SettingsScreen(dark, signedIn, pushEnabled, release, onPush = { on -> pushEnabled=on;activity.getSharedPreferences("mas-native",0).edit().putBoolean("push_enabled",on).apply();launch{val token=activity.getSharedPreferences("mas",0).getString("fcm","").orEmpty();if(on)repo.registerPush(token) else repo.unregisterPush(token)} }, onTheme = { dark = !dark; activity.getSharedPreferences("mas-native",0).edit().putBoolean("dark",dark).apply();activity.applyNativeTheme(dark) }, onSupport = { if (!signedIn) showAuth=true else launch { tickets=repo.tickets(); selectedTicket=JSONObject().put("new",true) } }, onRelease = { launch { release = repo.latestRelease(); if(release==null) toast("أنت على أحدث إصدار") else toast("الإصدار ${release?.optString("version_name")} متاح") } }, onInstallRelease = { r -> launch { val url=r.optString("apk_url"); if(url.isBlank()) throw IllegalStateException("رابط التحديث غير متاح"); NativeApi(activity).install(url,activity.packageName,"تحديث MAS STORE",r.optString("sha256")) } }, onLogout = { launch { try{repo.unregisterPush(activity.getSharedPreferences("mas",0).getString("fcm","").orEmpty())}catch(_:Exception){};repo.signOut(); signedIn=false; signedEmail=""; toast("تم تسجيل الخروج") } })
                }
                BottomBar(tab, dark) { tab = it }
            }
            if (busy && snapshot.products.isEmpty()) LoadingSpinner(dark,Modifier.align(Alignment.Center))
            if (toastText.isNotBlank()) LaunchedEffect(toastText) { delay(1800); toastText = "" }
        }
        if (showAuth) AuthDialog(repo, dark, onClose = { showAuth = false }, onGoogle = { try { activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(repo.createOAuthUrl()))) } catch (e: Exception) { toast(e.message ?: "تعذر فتح تسجيل Google") } }, onDone = { showAuth = false; signedIn=repo.isSignedIn; signedEmail=repo.email.orEmpty(); launch { reload(); try { if(pushEnabled)repo.registerPush(activity.getSharedPreferences("mas",0).getString("fcm","").orEmpty()) } catch (_: Exception) { } } })
        if (purchase != null) PaymentDialog(repo, purchase!!, snapshot.settings["vodafone_cash_number"].orEmpty(), dark, onClose = { purchase = null }, onSent = { purchase = null; toast("تم إرسال طلب الدفع للمراجعة") })
        if (selected != null) ProductDetails(activity, repo, selected!!, signedIn, dark, onClose = { selected = null }, onAction = { productAction(selected!!) }, onPay = { amount -> openPurchase(PurchaseTarget(product = selected, amount = amount)) }, onSupport = { if(signedIn) { launch { tickets=repo.tickets(); selectedTicket=JSONObject().put("new",true).put("product",selected?.optString("id")) } } else showAuth=true })
        if (selectedTicket != null) SupportDialog(repo, selectedTicket!!, tickets, dark, onClose = { selectedTicket = null }, onOpenTicket = { selectedTicket=it }, onCreated = { launch { tickets=repo.tickets(); toast("تم إرسال رسالتك للدعم") } })
    }
}

@Composable private fun Header(dark: Boolean, onTheme: () -> Unit, onAuth: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text("MAS STORE", fontSize = 19.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp); Text("متجرك الرقمي", color = Muted, fontSize = 12.sp) }
        TextButton(onClick = onTheme) { Text(if (dark) "☼" else "◐", fontSize = 20.sp, color = MaterialTheme.colorScheme.onSurface) }
        TextButton(onClick = onAuth) { Text("دخول", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold) }
    }
}

@Composable private fun BottomBar(tab: StoreTab, dark: Boolean, onSelect: (StoreTab) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp).clip(RoundedCornerShape(28.dp)).background(if(dark) DarkGlass else LightGlass).border(1.dp, Line, RoundedCornerShape(28.dp)).padding(4.dp), horizontalArrangement = Arrangement.SpaceAround) {
        StoreTab.values().forEach { item -> Column(Modifier.weight(1f).clip(CircleShape).clickable { onSelect(item) }.background(if(item==tab) MaterialTheme.colorScheme.onSurface.copy(alpha=.1f) else Color.Transparent).padding(vertical=7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(item.icon, fontSize=18.sp, color=MaterialTheme.colorScheme.onSurface); Text(item.title,fontSize=10.sp,color=MaterialTheme.colorScheme.onSurface,fontWeight=if(item==tab) FontWeight.Bold else FontWeight.Normal)
        } }
    }
}

@Composable private fun StoreScreen(snapshot: StoreSnapshot, busy: Boolean, search: String, onSearch: (String)->Unit, category: String, onCategory: (String)->Unit, sort: String, onSort:(String)->Unit, dark:Boolean, onProduct:(JSONObject)->Unit, onAction:(JSONObject)->Unit,onAnnouncement:(JSONObject)->Unit) {
    var query by remember { mutableStateOf(search) }
    val filtered = remember(snapshot.products, query, category, sort) {
        val items=snapshot.products.filter { p ->
            val q=query.trim().lowercase(); val title=p.optString("title")+" "+p.optString("description")
            (q.isBlank()||title.lowercase().contains(q)) && (category=="all"||category=="free"&&p.optDouble("price")==0.0||category=="paid"&&p.optDouble("price")>0||p.optString("category")==category)
        }
        when(sort){"price"->items.sortedBy{it.optDouble("price")};"rating"->items.sortedByDescending{it.optDouble("avg_rating")};else->items}
    }
    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.weight(1f), contentPadding=PaddingValues(start=16.dp,end=16.dp,bottom=18.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
            item { Column(Modifier.padding(top=4.dp,bottom=2.dp)) { Text("المتجر",fontSize=30.sp,fontWeight=FontWeight.Black); Text("اكتشف تطبيقات وألعاب ومواقع جديدة",fontSize=13.sp,color=Muted) } }
            val featured=snapshot.products.filter{it.optString("featured_headline").isNotBlank()}.take(6)
            if(featured.isNotEmpty()) item { Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text("مميز اليوم",fontSize=19.sp,fontWeight=FontWeight.Bold);LazyRow(horizontalArrangement=Arrangement.spacedBy(10.dp)){items(featured,key={it.optString("id")}){p->FeaturedProduct(p,dark,onProduct,onAction)}}} } }
            if(snapshot.announcements.isNotEmpty()) item { Text("إعلانات المتجر",fontSize=19.sp,fontWeight=FontWeight.Bold) }
            items(snapshot.announcements.asObjects(),key={it.optString("id")}) { a -> GlassCard(dark,Modifier.fillMaxWidth().clickable{onAnnouncement(a)}) { if(a.optString("image_url").startsWith("http"))ProductImage(a.optString("image_url"),Modifier.fillMaxWidth().height(140.dp),RoundedCornerShape(16.dp),a.optString("title"));Text(a.optString("title"),fontWeight=FontWeight.Bold); if(a.optString("body").isNotBlank())Text(a.optString("body"),color=Muted,maxLines=3);Text(when(a.optString("action")){"plans"->"عرض الباقات";"support"->"الدعم الفني";"appupdate"->"تحديث التطبيق";"product"->"عرض المنتج";else->"إعلان"},fontSize=11.sp,color=Muted) } }
            item { OutlinedTextField(query,onValueChange={query=it;onSearch(it)},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(30.dp),singleLine=true,placeholder={Text("ابحث في المتجر")},leadingIcon={Text("⌕",fontSize=23.sp)}) }
            item { Row(horizontalArrangement=Arrangement.spacedBy(6.dp), modifier=Modifier.horizontalScroll(rememberScrollState())) { listOf("all" to "الكل","app" to "تطبيقات","game" to "ألعاب","website" to "مواقع","free" to "مجاني","paid" to "مدفوع").forEach{(v,l)->FilterChip(selected=category==v,onClick={onCategory(v)},label={Text(l)},shape=CircleShape)} } }
            item { Row(verticalAlignment=Alignment.CenterVertically){Text("منتجات",fontWeight=FontWeight.Bold,fontSize=20.sp,modifier=Modifier.weight(1f)); var expanded by remember { mutableStateOf(false) }; Box { TextButton(onClick={expanded=true}){Text(if(sort=="rating")"الأعلى تقييمًا" else if(sort=="price")"الأرخص" else "الأحدث",color=MaterialTheme.colorScheme.onSurface)}; DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){ listOf("new" to "الأحدث","rating" to "الأعلى تقييمًا","price" to "الأرخص").forEach{(v,l)->DropdownMenuItem(text={Text(l)},onClick={onSort(v);expanded=false})} } } } }
            if(filtered.isEmpty()&&!busy) item { GlassCard(dark,Modifier.fillMaxWidth()){ Text("لا توجد منتجات مطابقة",color=Muted) } }
            items(filtered, key={it.optString("id")}) { product -> ProductRow(product,dark,onProduct,onAction) }
            if(snapshot.sections.isNotEmpty()) item { Text("اختيارات المتجر",fontWeight=FontWeight.Bold,fontSize=19.sp) }
            items(snapshot.sections,key={it.optString("id")}) { section ->
                val ids=section.optJSONArray("product_ids")?:JSONArray(); val matches=snapshot.products.filter{p->(0 until ids.length()).any{ids.optString(it)==p.optString("id")}}
                if(matches.isNotEmpty()) { Text(section.optString("title"),fontWeight=FontWeight.Bold); matches.take(5).forEach{ProductRow(it,dark,onProduct,onAction)} }
            }
        }
    }
}

@Composable private fun FeaturedProduct(p:JSONObject,dark:Boolean,onProduct:(JSONObject)->Unit,onAction:(JSONObject)->Unit) {
    GlassCard(dark,Modifier.width(238.dp).clickable{onProduct(p)}) {
        Row(verticalAlignment=Alignment.CenterVertically){ProductImage(p.optString("icon_url"),Modifier.size(54.dp),RoundedCornerShape(16.dp),p.optString("title"));Column(Modifier.padding(start=10.dp)){Text(p.optString("featured_headline").ifBlank{p.optString("title")},fontWeight=FontWeight.Bold,maxLines=2);Text(p.optString("title"),fontSize=12.sp,color=Muted,maxLines=1)}}
        Text(p.optString("short_description"),fontSize=12.sp,color=Muted,maxLines=2)
        TextButton(onClick={onAction(p)}){Text(if(p.optBoolean("coming_soon"))"قريبًا" else if(effectivePrice(p)==0.0)"مجاني" else money(effectivePrice(p)),fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onSurface)}
    }
}

@Composable private fun ProductRow(p:JSONObject,dark:Boolean,onProduct:(JSONObject)->Unit,onAction:(JSONObject)->Unit) {
    GlassCard(dark,Modifier.fillMaxWidth().clickable{onProduct(p)}) {
        Row(verticalAlignment=Alignment.CenterVertically) {
            ProductImage(p.optString("icon_url"),Modifier.size(58.dp),RoundedCornerShape(16.dp),p.optString("title"))
            Column(Modifier.weight(1f).padding(horizontal=12.dp)) {
                Text(p.optString("title"),fontSize=15.sp,fontWeight=FontWeight.Bold,maxLines=1)
                Text(p.optString("short_description").ifBlank{categoryLabel(p.optString("category"))},fontSize=12.sp,color=Muted,maxLines=2)
                Text("★ ${p.optDouble("avg_rating",0.0).let{String.format(Locale.US,"%.1f",it)}} · ${p.optInt("downloads")} تنزيل",fontSize=11.sp,color=Muted)
            }
            Column(horizontalAlignment=Alignment.End) {
                Text(if(p.optBoolean("coming_soon"))"قريبًا" else if(effectivePrice(p)==0.0)"مجاني" else money(effectivePrice(p)),fontSize=12.sp,fontWeight=FontWeight.Bold)
                TextButton(onClick={onAction(p)}){Text(if(p.optBoolean("coming_soon"))"سجّل" else if(p.optString("category")=="website")"فتح" else "تنزيل",fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onSurface)}
            }
        }
    }
}

@Composable private fun PlansScreen(packages:List<JSONObject>,dark:Boolean,onBuy:(JSONObject)->Unit) {
    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
            item { Text("الباقات",fontSize=30.sp,fontWeight=FontWeight.Black); Text("اشتراك شهري لتحميل منتجات أكثر",color=Muted) }
            if(packages.isEmpty()) item { GlassCard(dark,Modifier.fillMaxWidth()){Text("لا توجد باقات منشورة حاليًا",color=Muted)} }
            items(packages,key={it.optString("id")}) { p -> GlassCard(dark,Modifier.fillMaxWidth()) {
                Text(p.optString("name"),fontSize=20.sp,fontWeight=FontWeight.Bold)
                Text("${money(packagePrice(p))} / شهر",fontSize=26.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(vertical=8.dp))
                Text("${p.optInt("app_limit")} تطبيقات و${p.optInt("game_limit")} ألعاب",color=Muted)
                Text("حد سعر المنتج ${money(p.optDouble("max_item_price"))}",color=Muted)
                Button(onClick={onBuy(p)},modifier=Modifier.fillMaxWidth().padding(top=12.dp),shape=CircleShape){Text("اشترك الآن")}
            } }
        }
    }
}

@Composable private fun NoticeScreen(items:JSONArray,signed:Boolean,dark:Boolean,onLogin:()->Unit,onOpen:(JSONObject)->Unit) {
    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
            item { Text("الإشعارات",fontSize=28.sp,fontWeight=FontWeight.Black) }
            if(!signed) item { GlassCard(dark,Modifier.fillMaxWidth()) { Text("سجّل الدخول لعرض إشعاراتك."); Button(onClick=onLogin){Text("تسجيل الدخول")} } }
            else if(items.length()==0) item { GlassCard(dark,Modifier.fillMaxWidth()){Text("لا توجد إشعارات جديدة",color=Muted)} }
            items((0 until items.length()).mapNotNull{items.optJSONObject(it)},key={it.optString("id")}) { n -> GlassCard(dark,Modifier.fillMaxWidth().clickable{onOpen(n)}) {
                Text(n.optString("title"),fontWeight=FontWeight.Bold); Text(n.optString("body"),color=Muted); Text(n.optString("created_at").take(10),fontSize=11.sp,color=Muted)
            } }
        }
    }
}

@Composable private fun AccountScreen(signed:Boolean,email:String,account:JSONObject?,orders:JSONArray,dark:Boolean,onLogin:()->Unit,onLogout:()->Unit,onBirth:(String)->Unit,onSupport:()->Unit) {
    var birth by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
            item { Text("حسابي",fontSize=29.sp,fontWeight=FontWeight.Black) }
            if(!signed) item { GlassCard(dark,Modifier.fillMaxWidth()) { Text("سجّل الدخول لمتابعة اشتراكاتك وطلباتك",color=Muted); Button(onClick=onLogin,modifier=Modifier.fillMaxWidth()){Text("دخول / إنشاء حساب")} } }
            else {
                item { val sub=account?.optJSONObject("package"); val appsLeft=((sub?.optInt("app_limit")?:0)-(sub?.optInt("apps_used")?:0)).coerceAtLeast(0); val gamesLeft=((sub?.optInt("game_limit")?:0)-(sub?.optInt("games_used")?:0)).coerceAtLeast(0); GlassCard(dark,Modifier.fillMaxWidth()){Text(email,fontWeight=FontWeight.Bold); Text("ملخص الاشتراك",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=12.dp)); Text(sub?.optString("name") ?: "لا يوجد اشتراك نشط",color=Muted); Text("التطبيقات المتبقية: $appsLeft · الألعاب المتبقية: $gamesLeft",color=Muted) } }
                item { GlassCard(dark,Modifier.fillMaxWidth()) { Text("تاريخ الميلاد للمحتوى العمري",fontWeight=FontWeight.Bold); OutlinedTextField(birth,{birth=it},modifier=Modifier.fillMaxWidth(),label={Text("YYYY-MM-DD")},singleLine=true); Button(onClick={onBirth(birth)},modifier=Modifier.fillMaxWidth()){Text("حفظ التاريخ")} } }
                item { Row(verticalAlignment=Alignment.CenterVertically){Text("طلبات الدفع",fontSize=20.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f)); TextButton(onClick=onSupport){Text("الدعم الفني",color=MaterialTheme.colorScheme.onSurface)} } }
                items((0 until orders.length()).mapNotNull{orders.optJSONObject(it)},key={it.optString("id")}) { o -> GlassCard(dark,Modifier.fillMaxWidth()){Text(o.optJSONObject("products")?.optString("title") ?: o.optJSONObject("packages")?.optString("name") ?: "طلب متجر",fontWeight=FontWeight.Bold); Text("${money(o.optDouble("amount"))} · ${statusLabel(o.optString("status"))}",color=Muted); if(o.optString("rejection_reason").isNotBlank())Text(o.optString("rejection_reason"),color=Muted) } }
                item { OutlinedButton(onClick=onLogout,modifier=Modifier.fillMaxWidth(),shape=CircleShape){Text("تسجيل الخروج")} }
            }
        }
    }
}

@Composable private fun SettingsScreen(dark:Boolean,signed:Boolean,pushEnabled:Boolean,release:JSONObject?,onPush:(Boolean)->Unit,onTheme:()->Unit,onSupport:()->Unit,onRelease:()->Unit,onInstallRelease:(JSONObject)->Unit,onLogout:()->Unit) {
    Column(Modifier.fillMaxSize()) { LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { Text("الإعدادات",fontSize=29.sp,fontWeight=FontWeight.Black) }
        item { GlassCard(dark,Modifier.fillMaxWidth().clickable{onTheme()}) { Text("المظهر",fontWeight=FontWeight.Bold); Text(if(dark)"الوضع الداكن" else "الوضع الفاتح",color=Muted) } }
        item { GlassCard(dark,Modifier.fillMaxWidth()) { Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("الإشعارات",fontWeight=FontWeight.Bold);Text(if(pushEnabled)"مفعّلة" else "متوقفة",color=Muted)};Switch(checked=pushEnabled,onCheckedChange=onPush)} } }
        item { GlassCard(dark,Modifier.fillMaxWidth().clickable{onRelease()}) { Text("تحديث التطبيق",fontWeight=FontWeight.Bold); Text(release?.optString("version_name")?.let{"الإصدار المتاح $it"} ?: "تحقق من وجود إصدار جديد",color=Muted) } }
        if(release!=null) item { GlassCard(dark,Modifier.fillMaxWidth()) { Text(release.optString("changelog"),color=Muted); Button(onClick={onInstallRelease(release)},modifier=Modifier.fillMaxWidth(),shape=CircleShape){Text("تنزيل التحديث")}; if(release.optBoolean("is_mandatory")) Text("هذا التحديث مطلوب",fontWeight=FontWeight.Bold) } }
        item { GlassCard(dark,Modifier.fillMaxWidth().clickable{onSupport()}) { Text("الدعم الفني",fontWeight=FontWeight.Bold); Text("افتح تذكرة أو تابع طلبات الدعم",color=Muted) } }
        item { GlassCard(dark,Modifier.fillMaxWidth()) { Text("حول MAS STORE",fontWeight=FontWeight.Bold); Text("متجر التطبيقات والألعاب والمواقع",color=Muted); Text("يتم تحديث المنتجات والباقات من لوحة الإدارة مباشرة.",color=Muted) } }
        if(signed) item { OutlinedButton(onClick=onLogout,modifier=Modifier.fillMaxWidth(),shape=CircleShape){Text("تسجيل الخروج")} }
    } }
}

@Composable private fun AuthDialog(repo:StoreRepository,dark:Boolean,onClose:()->Unit,onGoogle:()->Unit,onDone:()->Unit) {
    var signUp by remember { mutableStateOf(false) }; var name by remember { mutableStateOf("") }; var email by remember { mutableStateOf("") }; var password by remember { mutableStateOf("") }; var birth by remember { mutableStateOf("") }; var busy by remember { mutableStateOf(false) }; var error by remember { mutableStateOf("") }; val scope= rememberCoroutineScope()
    Dialog(onDismissRequest=onClose) { GlassCard(dark,Modifier.fillMaxWidth()) {
        Text(if(signUp)"إنشاء حساب" else "سجّل دخولك",fontSize=22.sp,fontWeight=FontWeight.Black)
        OutlinedButton(onClick=onGoogle,modifier=Modifier.fillMaxWidth(),shape=CircleShape){Text("المتابعة بحساب Google")}
        if(signUp) OutlinedTextField(name,{name=it},modifier=Modifier.fillMaxWidth(),label={Text("الاسم")},singleLine=true)
        OutlinedTextField(email,{email=it},modifier=Modifier.fillMaxWidth(),label={Text("البريد الإلكتروني")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Email))
        OutlinedTextField(password,{password=it},modifier=Modifier.fillMaxWidth(),label={Text("كلمة المرور")},singleLine=true,visualTransformation=PasswordVisualTransformation())
        if(signUp) OutlinedTextField(birth,{birth=it},modifier=Modifier.fillMaxWidth(),label={Text("تاريخ الميلاد (اختياري YYYY-MM-DD)")},singleLine=true)
        if(error.isNotBlank()) Text(error,color=Muted)
        Button(enabled=!busy,onClick={scope.launch { busy=true; error=""; try { if(signUp) { repo.signUp(email,password,name); if(birth.isNotBlank()) repo.setBirthDate(birth) } else repo.signIn(email,password); onDone() } catch(e:Exception){error=e.message ?: "تعذر تسجيل الدخول"}; busy=false } },modifier=Modifier.fillMaxWidth(),shape=CircleShape){Text(if(busy)"جارٍ الاتصال..." else if(signUp)"إنشاء الحساب" else "دخول")}
        TextButton(onClick={signUp=!signUp;error=""}){Text(if(signUp)"لديك حساب؟ سجّل الدخول" else "ليس لديك حساب؟ أنشئ حسابًا",color=MaterialTheme.colorScheme.onSurface)}
        TextButton(onClick=onClose){Text("إغلاق",color=Muted)}
    } }
}

@Composable private fun PaymentDialog(repo:StoreRepository,target:PurchaseTarget,vodafoneNumber:String,dark:Boolean,onClose:()->Unit,onSent:()->Unit) {
    var reference by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }; var promo by remember { mutableStateOf("") }; var error by remember { mutableStateOf("") }; var busy by remember { mutableStateOf(false) }; val scope= rememberCoroutineScope()
    Dialog(onDismissRequest=onClose) { GlassCard(dark,Modifier.fillMaxWidth()) {
        Text("إتمام الدفع",fontSize=22.sp,fontWeight=FontWeight.Black)
        Text(target.product?.optString("title") ?: target.pack?.optString("name") ?: "طلب متجر",fontWeight=FontWeight.Bold)
        Text("المبلغ المبدئي: ${money(target.amount)}",fontSize=18.sp,fontWeight=FontWeight.Bold)
        Text("حوّل عبر Vodafone Cash إلى ${vodafoneNumber.ifBlank { "الرقم غير محدد" }} ثم اكتب رقم العملية. المراجعة يدوية.",color=Muted,fontSize=13.sp)
        OutlinedTextField(reference,{reference=it},modifier=Modifier.fillMaxWidth(),label={Text("رقم العملية")},singleLine=true)
        OutlinedTextField(phone,{phone=it},modifier=Modifier.fillMaxWidth(),label={Text("رقم المحفظة (اختياري)")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Phone))
        OutlinedTextField(promo,{promo=it},modifier=Modifier.fillMaxWidth(),label={Text("كود خصم (اختياري)")},singleLine=true)
        if(error.isNotBlank()) Text(error,color=Muted)
        Button(enabled=!busy&&reference.isNotBlank(),onClick={scope.launch { busy=true;error="";try { repo.createPayment(target.product?.optString("id"),target.pack?.optString("id"),reference,phone,promo);onSent() } catch(e:Exception){error=e.message?:"تعذر إرسال الطلب"};busy=false } },modifier=Modifier.fillMaxWidth(),shape=CircleShape){Text(if(busy)"جارٍ الإرسال..." else "إرسال طلب الدفع")}
        TextButton(onClick=onClose){Text("إلغاء",color=Muted)}
    } }
}

@Composable private fun ProductDetails(activity:MainActivity,repo:StoreRepository,p:JSONObject,signedIn:Boolean,dark:Boolean,onClose:()->Unit,onAction:()->Unit,onPay:(Double)->Unit,onSupport:()->Unit) {
    var reviews by remember { mutableStateOf(JSONArray()) }; var updates by remember { mutableStateOf(JSONArray()) }; var rating by remember { mutableIntStateOf(5) }; var comment by remember { mutableStateOf("") }; var error by remember { mutableStateOf("") }; val scope= rememberCoroutineScope()
    LaunchedEffect(p.optString("id")) { try { reviews=repo.reviews(p.optString("id")); updates=repo.updates(p.optString("id")) } catch (_:Exception){} }
    Dialog(onDismissRequest=onClose) { GlassCard(dark,Modifier.fillMaxWidth().heightIn(max=720.dp)) {
        Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically){ProductImage(p.optString("icon_url"),Modifier.size(72.dp),RoundedCornerShape(20.dp),p.optString("title")); Column(Modifier.weight(1f).padding(horizontal=10.dp)){Text(p.optString("title"),fontSize=21.sp,fontWeight=FontWeight.Black);Text(categoryLabel(p.optString("category")),color=Muted)};TextButton(onClick=onClose){Text("×",fontSize=24.sp,color=Muted)} }
            Text(p.optString("short_description"),fontSize=14.sp,color=Muted)
            Text("★ ${p.optDouble("avg_rating",0.0)} · ${p.optInt("review_count")} تقييم · ${p.optString("version","1.0")}",color=Muted)
            if(p.optBoolean("coming_soon")) Text("قريبًا",fontWeight=FontWeight.Bold)
            val shots=p.optJSONArray("screenshots")?:JSONArray(); if(shots.length()>0) LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)){items((0 until shots.length()).map{shots.optString(it)}){url->ProductImage(url,Modifier.width(220.dp).height(160.dp),RoundedCornerShape(18.dp),p.optString("title"))} }
            Text("الوصف",fontWeight=FontWeight.Bold,fontSize=17.sp); Text(p.optString("description").ifBlank{"لا يوجد وصف إضافي."},color=MaterialTheme.colorScheme.onSurface)
            Button(onClick=onAction,modifier=Modifier.fillMaxWidth(),shape=CircleShape){Text(if(p.optBoolean("coming_soon"))"سجّل مسبقًا" else if(p.optString("category")=="website")"فتح المنتج" else "تنزيل / شراء")}
            TextButton(onClick=onSupport){Text("الإبلاغ عن مشكلة",color=Muted)}
            if(updates.length()>0){Text("سجل التحديثات",fontWeight=FontWeight.Bold,fontSize=17.sp);(0 until updates.length()).forEach{val u=updates.optJSONObject(it)?:return@forEach;Text("${u.optString("version")} · ${u.optString("changelog")}",color=Muted)}}
            Text("التقييمات",fontWeight=FontWeight.Bold,fontSize=17.sp)
            (0 until reviews.length()).take(12).forEach { val r=reviews.optJSONObject(it)?:return@forEach; GlassCard(dark,Modifier.fillMaxWidth()){Text("${r.optString("name","مستخدم")} · ${"★".repeat(r.optInt("rating",0))}",fontWeight=FontWeight.Bold);Text(r.optString("comment"),color=Muted);if(r.optString("admin_reply").isNotBlank())Text("رد الإدارة: ${r.optString("admin_reply")}",color=Muted)} }
            if(signedIn){Text("اكتب تقييمك",fontWeight=FontWeight.Bold);Row{(1..5).forEach{TextButton(onClick={rating=it}){Text(if(it<=rating)"★" else "☆",fontSize=20.sp,color=MaterialTheme.colorScheme.onSurface)}}};OutlinedTextField(comment,{comment=it},modifier=Modifier.fillMaxWidth(),label={Text("تعليقك")});Button(onClick={scope.launch { try{repo.addReview(p.optString("id"),rating,comment);reviews=repo.reviews(p.optString("id"));comment="";toastLocal(activity,"تم حفظ تقييمك")}catch(e:Exception){error=e.message?:"تعذر حفظ التقييم"} }},modifier=Modifier.fillMaxWidth(),shape=CircleShape){Text("إرسال التقييم")};if(error.isNotBlank())Text(error,color=Muted)}
        }
    } }
}

@Composable private fun SupportDialog(repo:StoreRepository,ticket:JSONObject,tickets:JSONArray,dark:Boolean,onClose:()->Unit,onOpenTicket:(JSONObject)->Unit,onCreated:()->Unit) {
    var subject by remember { mutableStateOf("") }; var body by remember { mutableStateOf("") }; var reply by remember { mutableStateOf("") }; var messages by remember { mutableStateOf(JSONArray()) }; var error by remember { mutableStateOf("") }; val scope= rememberCoroutineScope(); val id=ticket.optString("id")
    LaunchedEffect(id){if(id.isNotBlank())try{messages=repo.ticketMessages(id)}catch(_:Exception){}}
    Dialog(onDismissRequest=onClose){GlassCard(dark,Modifier.fillMaxWidth().heightIn(max=680.dp)){
        Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(9.dp)){
            Row(verticalAlignment=Alignment.CenterVertically){Text("الدعم الفني",fontWeight=FontWeight.Black,fontSize=22.sp,modifier=Modifier.weight(1f));TextButton(onClick=onClose){Text("×",color=Muted)}}
            if(ticket.optBoolean("new")){
                Text("اكتب موضوع التذكرة وتفاصيل المشكلة",color=Muted)
                OutlinedTextField(subject,{subject=it},modifier=Modifier.fillMaxWidth(),label={Text("الموضوع")})
                OutlinedTextField(body,{body=it},modifier=Modifier.fillMaxWidth().height(130.dp),label={Text("التفاصيل")})
                if(error.isNotBlank())Text(error,color=Muted)
                Button(onClick={scope.launch{try{repo.createTicket("other",subject,body,ticket.optString("product").takeIf{it.isNotBlank()});onCreated();onClose()}catch(e:Exception){error=e.message?:"تعذر فتح التذكرة"}}},modifier=Modifier.fillMaxWidth(),shape=CircleShape){Text("إرسال التذكرة")}
                (0 until tickets.length()).forEach{val t=tickets.optJSONObject(it)?:return@forEach;TextButton(onClick={onOpenTicket(t)}){Text("${t.optString("subject")} · ${statusLabel(t.optString("status"))}",color=MaterialTheme.colorScheme.onSurface)}}
            }else{
                Text(ticket.optString("subject"),fontWeight=FontWeight.Bold)
                (0 until messages.length()).forEach{val m=messages.optJSONObject(it)?:return@forEach;GlassCard(dark,Modifier.fillMaxWidth()){Text(if(m.optString("sender")=="admin")"الدعم الفني" else "أنت",fontWeight=FontWeight.Bold);Text(m.optString("body"))}}
                OutlinedTextField(reply,{reply=it},modifier=Modifier.fillMaxWidth(),label={Text("اكتب ردك")})
                Button(onClick={scope.launch{try{repo.replyTicket(id,reply);messages=repo.ticketMessages(id);reply=""}catch(e:Exception){error=e.message?:"تعذر إرسال الرد"}}},modifier=Modifier.fillMaxWidth(),shape=CircleShape){Text("إرسال الرد")}
                if(ticket.optString("status")!="closed") OutlinedButton(onClick={scope.launch{try{repo.closeTicket(id);onClose()}catch(e:Exception){error=e.message?:"تعذر إغلاق التذكرة"}}},modifier=Modifier.fillMaxWidth(),shape=CircleShape){Text("إغلاق التذكرة")}
            }
        }
    }}
}

@Composable private fun GlassCard(dark:Boolean,modifier:Modifier=Modifier,content:@Composable ColumnScope.()->Unit) {
    Column(modifier.clip(Shape).background(if(dark) DarkGlass else LightGlass).border(1.dp,if(dark) Color.White.copy(alpha=.20f) else Color.White.copy(alpha=.92f),Shape).padding(16.dp),verticalArrangement=Arrangement.spacedBy(7.dp),content=content)
}

@Composable private fun LoadingSpinner(dark:Boolean,modifier:Modifier=Modifier) {
    val transition= rememberInfiniteTransition(label="native-spinner")
    val rotation by transition.animateFloat(0f,360f,animationSpec=infiniteRepeatable(tween(2600,easing=LinearEasing)),label="rotation")
    val pulse by transition.animateFloat(.88f,1.06f,animationSpec=infiniteRepeatable(tween(850,easing=FastOutSlowInEasing),RepeatMode.Reverse),label="pulse")
    Column(modifier,horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Box(Modifier.size(132.dp)) {
            repeat(8) { i -> Box(Modifier.align(Alignment.Center).size(132.dp).graphicsLayer { rotationZ=rotation+i*45f }) {
                Box(Modifier.align(Alignment.TopCenter).offset(y=8.dp).size(width=25.dp,height=52.dp).graphicsLayer {
                    scaleX=pulse; scaleY=pulse; alpha=.58f+((i+rotation/45f)%8f)/20f
                }.clip(CircleShape).background(Brush.linearGradient(if(dark) listOf(Color.White,Color(0xFF8A8A8A),Color(0xFFEDEDED)) else listOf(Color.White,Color(0xFFB7B7B7),Color.White))).border(1.dp,Color.White.copy(alpha=.8f),CircleShape))
            } }
        }
        Text("MAS STORE",fontSize=12.sp,fontWeight=FontWeight.Bold,letterSpacing=3.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.72f))
    }
}

@Composable private fun ProductImage(url:String,modifier:Modifier,shape:RoundedCornerShape,title:String) {
    if(url.startsWith("http")) AsyncImage(model=url,contentDescription=title,modifier=modifier.clip(shape).background(Color.Gray.copy(alpha=.2f)),contentScale=ContentScale.Crop)
    else Box(modifier.clip(shape).background(Brush.linearGradient(listOf(Color(0xFF777777),Color(0xFF333333)))),contentAlignment=Alignment.Center){Text(title.take(1),color=Color.White,fontSize=22.sp,fontWeight=FontWeight.Bold)}
}

private fun JSONArray.asObjects()=(0 until length()).mapNotNull{optJSONObject(it)}
private fun categoryLabel(c:String)=when(c){"app"->"تطبيق";"game"->"لعبة";"website"->"موقع";else->"منتج رقمي"}
private fun statusLabel(s:String)=when(s){"pending"->"قيد المراجعة";"approved"->"مقبول";"rejected"->"مرفوض";"answered"->"تم الرد";"closed"->"مغلق";else->s}
private fun money(n:Double)=NumberFormat.getNumberInstance(Locale("ar","EG")).format(n)+" ج.م"
private fun effectivePrice(p:JSONObject):Double { val price=p.optDouble("price");val sale=p.optInt("sale_percent");val end=p.optString("sale_ends_at");val active=sale>0&&(end.isBlank()||try{java.time.Instant.parse(end).toEpochMilli()>System.currentTimeMillis()}catch(_:Exception){false});return if(active)price*(100-sale.coerceIn(0,90))/100.0 else price }
private fun packagePrice(p:JSONObject):Double { val price=p.optDouble("price");val percent=p.optDouble("discount_percent",0.0).coerceIn(0.0,100.0);return (price*(100.0-percent)/100.0).let{String.format(Locale.US,"%.2f",it).toDouble()} }
private fun toastLocal(activity:MainActivity,text:String)=Toast.makeText(activity,text,Toast.LENGTH_SHORT).show()
