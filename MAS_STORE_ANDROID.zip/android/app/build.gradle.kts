plugins { id("com.android.application"); id("org.jetbrains.kotlin.android"); id("com.google.gms.google-services") }
android {
  buildFeatures { compose = true }
  composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
  namespace = "com.mas.store"
  compileSdk = 34
  defaultConfig { applicationId = "com.mas.store"; minSdk = 26; targetSdk = 34; versionCode = (project.findProperty("versionCode") as String?)?.toIntOrNull() ?: 2; versionName = (project.findProperty("versionName") as String?) ?: "2.1.0" }
  signingConfigs { create("mas") { storeFile = file("mas.p12"); storePassword = "masstore123"; keyAlias = "mas"; keyPassword = "masstore123"; storeType = "pkcs12" } }
  buildTypes { getByName("debug") { signingConfig = signingConfigs.getByName("mas") } }
  compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
  kotlinOptions { jvmTarget = "17" }
}
dependencies {
  implementation(platform("androidx.compose:compose-bom:2024.06.00"))
  implementation("androidx.activity:activity-compose:1.9.0")
  implementation("androidx.compose.ui:ui")
  implementation("androidx.compose.ui:ui-tooling-preview")
  implementation("androidx.compose.material3:material3")
  implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.3")
  implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.3")
  implementation("io.coil-kt:coil-compose:2.6.0")
  implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
  implementation("com.squareup.okhttp3:okhttp:4.12.0")
  implementation("androidx.core:core-ktx:1.13.1")
  implementation("androidx.appcompat:appcompat:1.7.0")
  implementation("androidx.browser:browser:1.8.0")
  implementation("androidx.webkit:webkit:1.11.0")
  implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
  implementation("com.google.firebase:firebase-messaging")
}
