# إشعارات Firebase (والتطبيق مقفول)

## الخطوات (مرة واحدة)
1) Supabase → SQL Editor → شغّل `features_v8_6.sql`.
2) Supabase → Edge Functions → Deploy a new function (Via Editor) → الاسم `fcm` → الصق محتوى `supabase/functions/fcm/index.ts` → Deploy.
3) Firebase → Project settings → Service accounts → Generate new private key (ملف JSON).
   Supabase → Edge Functions → Secrets → Add: الاسم `FCM_SERVICE_ACCOUNT` والقيمة = محتوى ملف JSON كامل. (سر: لا ترفعه في GitHub ولا ترسله لأحد)
4) Supabase → Database → Webhooks → Create: Name `fcm_push`، Table `notifications`، Events: Insert، Type: Supabase Edge Functions، Function: `fcm`، Method: POST.
5) GitHub: ارفع `MAS_STORE_ANDROID.zip` الجديد (فيه google-services.json) بنفس الاسم، استنى البناء، ونزّل الـ APK وثبّته فوق القديم.
6) افتح التطبيق مرة، سجّل دخول، واسمح بالإشعارات.

## اختبار
شغّل في SQL Editor (غيّر الإيميل):
insert into notifications(user_id,title,body) select id,'اختبار','إشعار تجريبي من MAS STORE' from profiles where email='your@email.com';
اقفل التطبيق تمامًا (من الأحدث) وانتظر ثواني: لازم يوصل إشعار بصوت واللوجو.

## ملاحظات
- لو أغلقت التطبيق بـ "إيقاف إجباري" من إعدادات الهاتف، أندرويد يمنع وصول الإشعارات لحد ما تفتحه.
- بعض أجهزة شاومي وهواوي ومثلها تحتاج: إعدادات التطبيق → البطارية → بدون قيود، والسماح بالتشغيل التلقائي.
- الإشعار بيظهر للمستخدم الداخل بحسابه. لو ضغطت على الإشعار بيفتح المنتج مباشرة.
