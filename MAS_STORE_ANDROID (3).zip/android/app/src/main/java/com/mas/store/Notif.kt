package com.mas.store

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Build
import androidx.core.app.NotificationCompat

object Notif {
    const val CH_PROG = "mas_progress"
    const val CH_DONE = "mas_done"

    fun init(c: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH_PROG, "التنزيل والتثبيت", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel(CH_DONE, "إشعارات المتجر", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    // اللوجو يظهر كصورة كبيرة في الإشعار + أيقونة صغيرة أحادية اللون (شرط أندرويد)
    fun builder(c: Context, ch: String): NotificationCompat.Builder =
        NotificationCompat.Builder(c, ch)
            .setSmallIcon(R.drawable.ic_stat)
            .setLargeIcon(BitmapFactory.decodeResource(c.resources, R.drawable.logo_large))
            .setColor(0xFF7C4DFF.toInt())

    fun openApp(c: Context): PendingIntent = PendingIntent.getActivity(
        c, 0, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    fun show(c: Context, id: Int, n: android.app.Notification) { c.getSystemService(NotificationManager::class.java).notify(id, n) }
    fun cancel(c: Context, id: Int) { c.getSystemService(NotificationManager::class.java).cancel(id) }
    fun nid(id: String): Int = 3000 + (id.hashCode() and 0xffff)
}
