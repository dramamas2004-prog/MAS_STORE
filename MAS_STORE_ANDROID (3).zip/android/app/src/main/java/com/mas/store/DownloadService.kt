package com.mas.store

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.ServiceCompat
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CancellationException
import java.util.concurrent.ConcurrentHashMap

class Item(val id: String, val title: String) {
    @Volatile var pc = 0
    @Volatile var state = "download"
    @Volatile var cancelled = false
    @Volatile var sid = -1
}

// خدمة تعمل في الخلفية: التنزيل يكمل حتى لو خرجت من التطبيق، وفيها إشعار تقدّم وزر إلغاء
class DownloadService : Service() {
    companion object {
        val active = ConcurrentHashMap<String, Item>()
        fun json(): String {
            val o = JSONObject()
            for ((k, v) in active) o.put(k, JSONObject().put("pc", v.pc).put("state", v.state))
            return o.toString()
        }
        fun cancelInstall(c: Context, item: Item) {
            item.cancelled = true
            try { if (item.sid >= 0) c.packageManager.packageInstaller.abandonSession(item.sid) } catch (e: Exception) {}
            active.remove(item.id)
            Notif.cancel(c, Notif.nid(item.id))
            Bridge.emit(JSONObject().put("type", "cancelled").put("id", item.id))
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        if (i == null) return START_NOT_STICKY
        Notif.init(this)
        val id = i.getStringExtra("id") ?: return START_NOT_STICKY
        when (i.action) {
            "START" -> {
                val url = i.getStringExtra("url") ?: return START_NOT_STICKY
                if (active.containsKey(id)) return START_NOT_STICKY
                val item = Item(id, i.getStringExtra("title") ?: "تطبيق")
                active[id] = item
                val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
                ServiceCompat.startForeground(this, 1, notif(item, "جاري التنزيل 0%"), type)
                Thread { run(item, url) }.start()
            }
            "CANCEL" -> {
                val item = active[id]
                if (item != null) {
                    if (item.state == "install") cancelInstall(this, item) else item.cancelled = true
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun notif(item: Item, txt: String): Notification {
        val cancel = PendingIntent.getService(this, item.id.hashCode(),
            Intent(this, DownloadService::class.java).setAction("CANCEL").putExtra("id", item.id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notif.builder(this, Notif.CH_PROG).setContentTitle(item.title).setContentText(txt)
            .setOngoing(true).setOnlyAlertOnce(true).setProgress(100, item.pc, item.state != "download")
            .setContentIntent(Notif.openApp(this)).addAction(0, "إلغاء", cancel).build()
    }

    private fun end(item: Item, type: String, msg: String?) {
        active.remove(item.id)
        Bridge.emit(JSONObject().put("type", type).put("id", item.id).put("msg", msg ?: ""))
        if (type == "error") {
            Notif.show(this, Notif.nid(item.id), Notif.builder(this, Notif.CH_DONE).setContentTitle("تعذر تثبيت " + item.title)
                .setContentText(msg ?: "حاول مرة أخرى").setAutoCancel(true).setContentIntent(Notif.openApp(this)).build())
        }
    }

    private fun run(item: Item, url: String) {
        val f = File(cacheDir, "dl-" + item.id + ".apk")
        try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 20000; c.readTimeout = 30000; c.connect()
            if (c.responseCode != 200) throw Exception("HTTP " + c.responseCode)
            val total = c.contentLengthLong
            var got = 0L; var last = -1; var lastT = 0L
            c.inputStream.use { inp -> f.outputStream().use { out ->
                val buf = ByteArray(65536)
                while (true) {
                    if (item.cancelled) throw CancellationException()
                    val n = inp.read(buf); if (n < 0) break
                    out.write(buf, 0, n); got += n
                    if (total > 0) {
                        val pc = (got * 100 / total).toInt()
                        if (pc != last) {
                            last = pc; item.pc = pc
                            Bridge.emit(JSONObject().put("type", "progress").put("id", item.id).put("pc", pc))
                            val now = System.currentTimeMillis()
                            if (now - lastT > 700) { lastT = now; Notif.show(this, 1, notif(item, "جاري التنزيل $pc%")) }
                        }
                    }
                }
            } }
            if (item.cancelled) throw CancellationException()
            item.state = "install"; item.pc = 100
            Notif.show(this, 1, notif(item, "جاري التثبيت..."))
            val pkg = packageManager.getPackageArchiveInfo(f.path, 0)?.packageName ?: ""
            val inst = packageManager.packageInstaller
            val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
            if (pkg.isNotEmpty()) params.setAppPackageName(pkg)
            val sid = inst.createSession(params); item.sid = sid
            inst.openSession(sid).use { s ->
                f.inputStream().use { i -> s.openWrite("app.apk", 0, f.length()).use { o -> i.copyTo(o); s.fsync(o) } }
                if (item.cancelled) throw CancellationException()
                val pend = PendingIntent.getBroadcast(this, sid,
                    Intent(this, InstallReceiver::class.java).putExtra("id", item.id).putExtra("pkg", pkg).putExtra("title", item.title).setPackage(packageName),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
                s.commit(pend.intentSender)
            }
            Bridge.emit(JSONObject().put("type", "installing").put("id", item.id).put("pkg", pkg))
        } catch (e: CancellationException) {
            try { if (item.sid >= 0) packageManager.packageInstaller.abandonSession(item.sid) } catch (x: Exception) {}
            end(item, "cancelled", null)
        } catch (e: Exception) {
            end(item, "error", e.message)
        } finally {
            f.delete()
            val next = active.values.firstOrNull { it.state == "download" }
            if (next != null) Notif.show(this, 1, notif(next, "جاري التنزيل " + next.pc + "%"))
            else { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
        }
    }
}
