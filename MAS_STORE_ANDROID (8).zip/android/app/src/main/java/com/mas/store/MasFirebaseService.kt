package com.mas.store

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import org.json.JSONObject

// يستقبل إشعارات Firebase حتى لو التطبيق مقفول ويعرضها بصوت الهاتف وباللوجو
class MasFirebaseService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        getSharedPreferences("mas", Context.MODE_PRIVATE).edit().putString("fcm", token).apply()
        Bridge.emit(JSONObject().put("type", "fcmtoken"))
    }

    override fun onMessageReceived(m: RemoteMessage) {
        // لو المتجر مفتوح قدامك، الإشعار بيظهر جواه فقط (من غير تكرار)
        if (MainActivity.visible) return
        val d = m.data
        val title = d["title"] ?: "MAS STORE"
        val body = d["body"] ?: ""
        Notif.init(this)
        val open = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pid = d["product_id"]
        if (!pid.isNullOrEmpty()) open.putExtra("product_id", pid)
        val nid = 4000 + (System.currentTimeMillis() % 90000).toInt()
        val pi = PendingIntent.getActivity(this, nid, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notif.builder(this, Notif.CH_DONE).setContentTitle(title).setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true).setContentIntent(pi).setDefaults(Notification.DEFAULT_ALL).build()
        Notif.show(this, nid, n)
    }
}
