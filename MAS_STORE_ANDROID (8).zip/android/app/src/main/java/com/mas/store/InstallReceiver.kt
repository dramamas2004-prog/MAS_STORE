package com.mas.store

import android.app.Notification
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Build
import org.json.JSONObject

class InstallReceiver : BroadcastReceiver() {
    @Suppress("DEPRECATION")
    private fun confirmIntent(i: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java) else i.getParcelableExtra(Intent.EXTRA_INTENT)

    override fun onReceive(c: Context, i: Intent) {
        val id = i.getStringExtra("id") ?: ""
        val pkg = i.getStringExtra("pkg") ?: ""
        val title = i.getStringExtra("title") ?: "التطبيق"
        val nid = Notif.nid(id)
        Notif.init(c)
        when (i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                val ui = confirmIntent(i) ?: return
                ui.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (MainActivity.visible) c.startActivity(ui)
                else {
                    val pi = PendingIntent.getActivity(c, nid, ui, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                    Notif.show(c, nid, Notif.builder(c, Notif.CH_DONE).setContentTitle(title).setContentText("اضغط هنا لتأكيد التثبيت")
                        .setAutoCancel(true).setContentIntent(pi).setDefaults(Notification.DEFAULT_ALL).build())
                }
                Bridge.emit(JSONObject().put("type", "confirm").put("id", id))
            }
            PackageInstaller.STATUS_SUCCESS -> {
                DownloadService.active.remove(id)
                Notif.cancel(c, nid)
                val launch = c.packageManager.getLaunchIntentForPackage(pkg)
                val pi = if (launch != null) PendingIntent.getActivity(c, nid, launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT) else Notif.openApp(c)
                val b = Notif.builder(c, Notif.CH_DONE).setContentTitle("تم التثبيت ✓").setContentText(title + " جاهز للفتح")
                    .setAutoCancel(true).setContentIntent(pi).setDefaults(Notification.DEFAULT_ALL)
                if (launch != null) b.addAction(0, "فتح", pi)
                Notif.show(c, nid + 1, b.build())
                Bridge.emit(JSONObject().put("type", "done").put("id", id).put("pkg", pkg))
            }
            PackageInstaller.STATUS_FAILURE_ABORTED -> {
                DownloadService.active.remove(id)
                Notif.cancel(c, nid)
                Bridge.emit(JSONObject().put("type", "cancelled").put("id", id))
            }
            else -> {
                DownloadService.active.remove(id)
                Notif.cancel(c, nid)
                Bridge.emit(JSONObject().put("type", "error").put("id", id).put("msg", i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: "فشل التثبيت"))
            }
        }
    }
}
