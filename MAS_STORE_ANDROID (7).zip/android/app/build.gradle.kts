plugins { id("com.android.application"); id("org.jetbrains.kotlin.android"); id("com.google.gms.google-services") }
android {
  namespace = "com.mas.store"
  compileSdk = 34
  defaultConfig { applicationId = "com.mas.store"; minSdk = 26; targetSdk = 34; versionCode = (project.findProperty("versionCode") as String?)?.toIntOrNull() ?: 1; versionName = "1.3" }
  signingConfigs { create("mas") { storeFile = file("mas.p12"); storePassword = "masstore123"; keyAlias = "mas"; keyPassword = "masstore123"; storeType = "pkcs12" } }
  buildTypes { getByName("debug") { signingConfig = signingConfigs.getByName("mas") } }
  compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
  kotlinOptions { jvmTarget = "17" }
}
dependencies {
  implementation("androidx.core:core-ktx:1.13.1")
  implementation("androidx.appcompat:appcompat:1.7.0")
  implementation("androidx.browser:browser:1.8.0")
  implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
  implementation("com.google.firebase:firebase-messaging")
}
